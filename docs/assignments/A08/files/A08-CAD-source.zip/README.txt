A8 - Rick Bhattacharya - CAD source package

Gearbox assembly.3mf: final exported assembly mesh, not a parametric CAD file.
shaft 1.SLDPRT and shaft 2 .25.SLDPRT: native shaft component files.
7880K19 and 7880K24 files: supplied pinion and gear models (SOLIDWORKS and STEP).
Assem1.SLDASM and Assem2.SLDASM: original working assembly saves.

Original filenames are retained to preserve assembly reference names. Keep all
files together when opening in SOLIDWORKS. Native assembly saves can depend on
external component paths. The source folder contains no separate native housing,
cover, or bearing part; the 3MF includes the exported housing geometry.
